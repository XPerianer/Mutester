class A:
    # These are very long comments
    # These are very long comments
    # These are very long comments
    # These are very long comments
    def __init__(self, parameter: str):
        # These are very long comments
        # These are very long comments
        # These are very long comments
        # These are very long comments
        self.parameter = parameter

    def square(self, x):
        return x * x

    # These are very long comments
    # These are very long comments
    # These are very long comments
    # These are very long comments
    # These are very long comments
    # These are very long comments
    def another_function(self, y = int):
        def yet_another_help_function(y):
            return y + 2

        return yet_another_help_function(y)

    # These are very long comments
    # These are very long comments
